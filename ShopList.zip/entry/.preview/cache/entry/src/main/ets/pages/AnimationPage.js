import router from '@ohos:router';
class AnimationPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__fishX = new ObservedPropertySimplePU(200, this, "fishX");
        this.__fishY = new ObservedPropertySimplePU(180
        // 小鱼角度
        , this, "fishY");
        this.__angle = new ObservedPropertySimplePU(0
        // 小鱼图片
        , this, "angle");
        this.__src = new ObservedPropertyObjectPU({ "id": 16777235, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" }, this, "src");
        this.__isBegin = new ObservedPropertySimplePU(false, this, "isBegin");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.fishX !== undefined) {
            this.fishX = params.fishX;
        }
        if (params.fishY !== undefined) {
            this.fishY = params.fishY;
        }
        if (params.angle !== undefined) {
            this.angle = params.angle;
        }
        if (params.src !== undefined) {
            this.src = params.src;
        }
        if (params.isBegin !== undefined) {
            this.isBegin = params.isBegin;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__fishX.purgeDependencyOnElmtId(rmElmtId);
        this.__fishY.purgeDependencyOnElmtId(rmElmtId);
        this.__angle.purgeDependencyOnElmtId(rmElmtId);
        this.__src.purgeDependencyOnElmtId(rmElmtId);
        this.__isBegin.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__fishX.aboutToBeDeleted();
        this.__fishY.aboutToBeDeleted();
        this.__angle.aboutToBeDeleted();
        this.__src.aboutToBeDeleted();
        this.__isBegin.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get fishX() {
        return this.__fishX.get();
    }
    set fishX(newValue) {
        this.__fishX.set(newValue);
    }
    get fishY() {
        return this.__fishY.get();
    }
    set fishY(newValue) {
        this.__fishY.set(newValue);
    }
    get angle() {
        return this.__angle.get();
    }
    set angle(newValue) {
        this.__angle.set(newValue);
    }
    get src() {
        return this.__src.get();
    }
    set src(newValue) {
        this.__src.set(newValue);
    }
    get isBegin() {
        return this.__isBegin.get();
    }
    set isBegin(newValue) {
        this.__isBegin.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/AnimationPage.ets(17:5)");
            Row.height('100%');
            Row.width('100%');
            Row.backgroundImage({ "id": 16777241, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Row.backgroundImageSize({ height: '105%', width: '100%' });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create();
            Stack.debugLine("pages/AnimationPage.ets(18:7)");
            Stack.height('100%');
            Stack.width('100%');
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 返回按钮
            Button.createWithLabel('返回');
            Button.debugLine("pages/AnimationPage.ets(20:9)");
            // 返回按钮
            Button.position({ x: 0, y: 0 });
            // 返回按钮
            Button.backgroundColor('#20101010');
            // 返回按钮
            Button.onClick(() => {
                // 返回上一页
                router.back();
            });
            if (!isInitialRender) {
                // 返回按钮
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 返回按钮
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (!this.isBegin) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        // 开始按钮
                        Button.createWithLabel('开始游戏');
                        Button.debugLine("pages/AnimationPage.ets(30:11)");
                        // 开始按钮
                        Button.onClick(() => {
                            Context.animateTo({ duration: 1000 }, () => {
                                // 点击后显示小鱼
                                this.isBegin = true;
                            });
                        });
                        if (!isInitialRender) {
                            // 开始按钮
                            Button.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    // 开始按钮
                    Button.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        // 小鱼图片
                        Image.create(this.src);
                        Image.debugLine("pages/AnimationPage.ets(42:11)");
                        // 小鱼图片
                        Image.position({ x: this.fishX - 20, y: this.fishY - 20 });
                        // 小鱼图片
                        Image.rotate({ angle: this.angle, centerX: '50%', centerY: '50%' });
                        // 小鱼图片
                        Image.width(40);
                        // 小鱼图片
                        Image.height(40);
                        // 小鱼图片
                        Image.transition({
                            type: TransitionType.Insert,
                            opacity: 0,
                            translate: { x: -250 }
                        });
                        if (!isInitialRender) {
                            // 小鱼图片
                            Image.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                });
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 操作按钮
            Row.create();
            Row.debugLine("pages/AnimationPage.ets(55:9)");
            // 操作按钮
            Row.height(240);
            // 操作按钮
            Row.width(240);
            // 操作按钮
            Row.justifyContent(FlexAlign.Center);
            // 操作按钮
            Row.position({ x: 0, y: 120 });
            if (!isInitialRender) {
                // 操作按钮
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('←');
            Button.debugLine("pages/AnimationPage.ets(56:11)");
            Button.backgroundColor('#20101010');
            Button.onClick(() => {
                Context.animateTo({ duration: 500 }, () => {
                    this.fishX -= 20;
                    this.src = { "id": 16777232, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" };
                });
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 40 });
            Column.debugLine("pages/AnimationPage.ets(66:11)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('↑');
            Button.debugLine("pages/AnimationPage.ets(67:13)");
            Button.backgroundColor('#20101010');
            Button.onClick(() => {
                Context.animateTo({ duration: 500 }, () => {
                    this.fishY -= 20;
                });
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('↓');
            Button.debugLine("pages/AnimationPage.ets(76:13)");
            Button.backgroundColor('#20101010');
            Button.onClick(() => {
                Context.animateTo({ duration: 500 }, () => {
                    this.fishY += 20;
                });
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('→');
            Button.debugLine("pages/AnimationPage.ets(86:11)");
            Button.backgroundColor('#20101010');
            Button.onClick(() => {
                Context.animateTo({ duration: 500 }, () => {
                    this.fishX += 20;
                    this.src = { "id": 16777235, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" };
                });
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        // 操作按钮
        Row.pop();
        Stack.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new AnimationPage(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=AnimationPage.js.map