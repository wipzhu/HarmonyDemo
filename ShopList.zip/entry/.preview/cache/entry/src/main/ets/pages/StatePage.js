import { Header } from '@bundle:com.example.myapplication/entry/ets/common/components/CommonComponents';
class Person {
    constructor(name, age, gf) {
        this.name = name;
        this.age = age;
        this.gf = gf;
    }
}
class StatePage2 extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.idx = 1;
        this.__p = new ObservedPropertyObjectPU(new Person('Jack', 21, new Person('柔丝', 18)), this, "p");
        this.__gfs = new ObservedPropertyObjectPU([
            new Person('柔丝', 18),
            new Person('露西', 19),
        ], this, "gfs");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.idx !== undefined) {
            this.idx = params.idx;
        }
        if (params.p !== undefined) {
            this.p = params.p;
        }
        if (params.gfs !== undefined) {
            this.gfs = params.gfs;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__p.purgeDependencyOnElmtId(rmElmtId);
        this.__gfs.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__p.aboutToBeDeleted();
        this.__gfs.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get p() {
        return this.__p.get();
    }
    set p(newValue) {
        this.__p.set(newValue);
    }
    get gfs() {
        return this.__gfs.get();
    }
    set gfs(newValue) {
        this.__gfs.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 10 });
            Column.debugLine("pages/StatePage.ets(26:5)");
            Column.width('100%');
            Column.height('100%');
            Column.padding(10);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new Header(this, {}, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`${this.p.name} : ${this.p.age}`);
            Text.debugLine("pages/StatePage.ets(29:7)");
            Text.fontSize(50);
            Text.fontWeight(FontWeight.Bold);
            Text.onClick(() => {
                this.p.age++;
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`${this.p.gf.name} : ${this.p.gf.age}`);
            Text.debugLine("pages/StatePage.ets(35:7)");
            Text.fontSize(50);
            Text.fontWeight(FontWeight.Bold);
            Text.onClick(() => {
                this.p.gf.age++;
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('添加');
            Button.debugLine("pages/StatePage.ets(41:7)");
            Button.onClick(() => {
                this.gfs.push(new Person('女友' + this.idx++, 20));
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('=女友列表=');
            Text.debugLine("pages/StatePage.ets(46:7)");
            Text.fontSize(50);
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = (_item, index) => {
                const p = _item;
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Row.create();
                    Row.debugLine("pages/StatePage.ets(52:11)");
                    Row.width('100%');
                    Row.justifyContent(FlexAlign.SpaceBetween);
                    if (!isInitialRender) {
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create(`${p.name} : ${p.age}`);
                    Text.debugLine("pages/StatePage.ets(53:13)");
                    Text.fontSize(30);
                    Text.onClick(() => {
                        this.gfs[index] = new Person(p.name, p.age + 1);
                    });
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Button.createWithLabel('删除');
                    Button.debugLine("pages/StatePage.ets(58:13)");
                    Button.onClick(() => {
                        this.gfs.splice(index, 1);
                    });
                    if (!isInitialRender) {
                        Button.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Button.pop();
                Row.pop();
            };
            this.forEachUpdateFunction(elmtId, this.gfs, forEachItemGenFunction, undefined, true, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class StatePage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__name = new ObservedPropertySimplePU('Jack', this, "name");
        this.__age = new ObservedPropertySimplePU(21, this, "age");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.name !== undefined) {
            this.name = params.name;
        }
        if (params.age !== undefined) {
            this.age = params.age;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__name.purgeDependencyOnElmtId(rmElmtId);
        this.__age.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__name.aboutToBeDeleted();
        this.__age.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get name() {
        return this.__name.get();
    }
    set name(newValue) {
        this.__name.set(newValue);
    }
    get age() {
        return this.__age.get();
    }
    set age(newValue) {
        this.__age.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/StatePage.ets(82:5)");
            Column.width('100%');
            Column.height('100%');
            Column.justifyContent(FlexAlign.Center);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`${this.name} : ${this.age}`);
            Text.debugLine("pages/StatePage.ets(83:7)");
            Text.fontSize(50);
            Text.fontWeight(FontWeight.Bold);
            Text.onClick(() => {
                this.age++;
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new StatePage2(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=StatePage.js.map