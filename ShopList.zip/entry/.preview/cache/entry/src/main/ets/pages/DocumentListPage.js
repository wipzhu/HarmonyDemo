import { Header } from '@bundle:com.example.myapplication/entry/ets/common/components/CommonComponents';
class DocumentListPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.index = 1;
        this.__docs = new ObservedPropertyObjectPU([], this, "docs");
        this.context = getContext(this);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.index !== undefined) {
            this.index = params.index;
        }
        if (params.docs !== undefined) {
            this.docs = params.docs;
        }
        if (params.context !== undefined) {
            this.context = params.context;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__docs.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__docs.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get docs() {
        return this.__docs.get();
    }
    set docs(newValue) {
        this.__docs.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/DocumentListPage.ets(13:5)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 10 });
            Column.debugLine("pages/DocumentListPage.ets(14:7)");
            Column.width('100%');
            Column.height('100%');
            Column.padding(20);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new Header(this, { title: '文档列表' }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Divider.create();
            Divider.debugLine("pages/DocumentListPage.ets(16:9)");
            if (!isInitialRender) {
                Divider.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('新建文档');
            Button.debugLine("pages/DocumentListPage.ets(17:9)");
            Button.onClick(() => {
                // 添加文档
                this.docs.push(this.index);
                // 跳转到文档编辑的 UIAbility
                // 跳转的目的地want
                let want = {
                    deviceId: '',
                    bundleName: 'com.example.myapplication',
                    moduleName: 'entry',
                    abilityName: 'DocumentAbility',
                    parameters: {
                        instanceKey: 'idx_' + this.index++
                    }
                };
                // 跳转
                this.context.startAbility(want);
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const id = _item;
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Row.create({ space: 10 });
                    Row.debugLine("pages/DocumentListPage.ets(37:11)");
                    Row.width('100%');
                    if (!isInitialRender) {
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Image.create({ "id": 16777244, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                    Image.debugLine("pages/DocumentListPage.ets(38:13)");
                    Image.width(20);
                    if (!isInitialRender) {
                        Image.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create(`文档${id}`);
                    Text.debugLine("pages/DocumentListPage.ets(40:13)");
                    Text.fontSize(18);
                    Text.onClick(() => {
                        // 跳转到文档编辑的 UIAbility
                        // 跳转的目的地want
                        let want = {
                            deviceId: '',
                            bundleName: 'com.example.myapplication',
                            moduleName: 'entry',
                            abilityName: 'DocumentAbility',
                            parameters: {
                                instanceKey: 'idx_' + id
                            }
                        };
                        // 跳转
                        this.context.startAbility(want);
                    });
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                Row.pop();
            };
            this.forEachUpdateFunction(elmtId, this.docs, forEachItemGenFunction);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        Column.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new DocumentListPage(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=DocumentListPage.js.map