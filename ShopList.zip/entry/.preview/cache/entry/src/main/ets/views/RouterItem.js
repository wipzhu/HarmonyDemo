import router from '@ohos:router';
export default class RouterItem extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.r = undefined;
        this.i = undefined;
        this.__fontSize = this.initializeConsume("fontSize", "fontSize");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.r !== undefined) {
            this.r = params.r;
        }
        if (params.i !== undefined) {
            this.i = params.i;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        this.__fontSize.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get fontSize() {
        return this.__fontSize.get();
    }
    set fontSize(newValue) {
        this.__fontSize.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("views/RouterItem.ets(12:5)");
            Row.width('90%');
            Row.padding(12);
            Row.backgroundColor('#38f');
            Row.borderRadius(20);
            Row.shadow({ radius: 6, color: '#4F000000', offsetX: 2, offsetY: 4 });
            Row.onClick(() => {
                // router跳转
                router.pushUrl({
                    url: this.r.url,
                    params: { id: this.i }
                }, router.RouterMode.Single, err => {
                    if (err) {
                        console.log(`路由失败，errCode: ${err.code} errMsg:${err.message}`);
                    }
                });
            });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.i + '.');
            Text.debugLine("views/RouterItem.ets(13:7)");
            Text.fontSize(this.fontSize);
            Text.fontColor(Color.White);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Blank.create();
            Blank.debugLine("views/RouterItem.ets(16:7)");
            if (!isInitialRender) {
                Blank.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Blank.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.r.title);
            Text.debugLine("views/RouterItem.ets(17:7)");
            Text.fontSize(this.fontSize);
            Text.fontColor(Color.White);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=RouterItem.js.map