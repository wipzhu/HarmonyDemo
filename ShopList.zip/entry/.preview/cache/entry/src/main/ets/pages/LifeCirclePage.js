import { Header } from '@bundle:com.example.myapplication/entry/ets/common/components/CommonComponents';
class LifeCircle extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__show = new ObservedPropertySimplePU(false, this, "show");
        this.__arr = new ObservedPropertyObjectPU([], this, "arr");
        this.tag = 'Life Circle Page';
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.show !== undefined) {
            this.show = params.show;
        }
        if (params.arr !== undefined) {
            this.arr = params.arr;
        }
        if (params.tag !== undefined) {
            this.tag = params.tag;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__show.purgeDependencyOnElmtId(rmElmtId);
        this.__arr.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__show.aboutToBeDeleted();
        this.__arr.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get show() {
        return this.__show.get();
    }
    set show(newValue) {
        this.__show.set(newValue);
    }
    get arr() {
        return this.__arr.get();
    }
    set arr(newValue) {
        this.__arr.set(newValue);
    }
    aboutToAppear() {
        console.log(this.tag, 'about to appear');
    }
    onPageShow() {
        console.log(this.tag, 'on page show');
    }
    onBackPress() {
        console.log(this.tag, 'on back press');
    }
    onPageHide() {
        console.log(this.tag, 'on page hide');
    }
    aboutToDisappear() {
        console.log(this.tag, 'about to disappear');
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 20 });
            Column.debugLine("pages/LifeCirclePage.ets(33:5)");
            Column.width('100%');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new 
                    // 顶部标题
                    Header(this, { title: '测试组件生命周期' }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 按钮
            Button.createWithLabel('切换显示');
            Button.debugLine("pages/LifeCirclePage.ets(38:7)");
            // 按钮
            Button.onClick(() => this.show = !this.show);
            if (!isInitialRender) {
                // 按钮
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 按钮
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/LifeCirclePage.ets(41:7)");
            Row.height(30);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (this.show) {
                this.ifElseBranchUpdateFunction(0, () => {
                    {
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            if (isInitialRender) {
                                ViewPU.create(new MyText(this, { message: 'Hello World!' }, undefined, elmtId));
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                    }
                });
            }
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 新增按钮
            Button.createWithLabel('新增数据');
            Button.debugLine("pages/LifeCirclePage.ets(49:7)");
            // 新增按钮
            Button.onClick(() => this.arr.push('user_' + this.arr.length));
            if (!isInitialRender) {
                // 新增按钮
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 新增按钮
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = (_item, index) => {
                const item = _item;
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new MyText(this, { message: item, index: index, delete: this.delete.bind(this) }, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
            };
            this.forEachUpdateFunction(elmtId, this.arr, forEachItemGenFunction, undefined, true, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        Column.pop();
    }
    delete(index = -1) {
        if (index > -1) {
            this.arr.splice(index, 1);
        }
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class MyText extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.message = undefined;
        this.index = undefined;
        this.delete = undefined;
        this.tag = 'MyText Page';
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
        if (params.index !== undefined) {
            this.index = params.index;
        }
        if (params.delete !== undefined) {
            this.delete = params.delete;
        }
        if (params.tag !== undefined) {
            this.tag = params.tag;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    aboutToAppear() {
        console.log(this.tag, 'about to appear');
    }
    onPageShow() {
        console.log(this.tag, 'on page show');
    }
    onBackPress() {
        console.log(this.tag, 'on back press');
    }
    onPageHide() {
        console.log(this.tag, 'on page hide');
    }
    aboutToDisappear() {
        console.log(this.tag, 'about to disappear');
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/LifeCirclePage.ets(97:5)");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceAround);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.message);
            Text.debugLine("pages/LifeCirclePage.ets(98:7)");
            Text.fontSize(20);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (this.delete) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Image.create({ "id": 16777234, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                        Image.debugLine("pages/LifeCirclePage.ets(101:9)");
                        Image.width(20);
                        Image.onClick(() => this.delete(this.index));
                        if (!isInitialRender) {
                            Image.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                });
            }
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new LifeCircle(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=LifeCirclePage.js.map