import TaskStatistics from '@bundle:com.example.myapplication/entry/ets/views/TaskStatistics';
class TargetManage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.latestUpdateDate = '2023-12-01';
        this.totalTaskNumber = 0;
        this.completeTaskNumber = 3;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.latestUpdateDate !== undefined) {
            this.latestUpdateDate = params.latestUpdateDate;
        }
        if (params.totalTaskNumber !== undefined) {
            this.totalTaskNumber = params.totalTaskNumber;
        }
        if (params.completeTaskNumber !== undefined) {
            this.completeTaskNumber = params.completeTaskNumber;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/TargetManagePage.ets(12:5)");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#F1F2F3');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 标题
        this.Title.bind(this)();
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new 
                    // 整体进度
                    TaskStatistics(this, { latestUpdateDate: this.latestUpdateDate, totalTaskNumber: this.totalTaskNumber, completeTaskNumber: this.completeTaskNumber }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        Column.pop();
    }
    Title(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('工作目标');
            Text.debugLine("pages/TargetManagePage.ets(27:5)");
            Text.width('86.7%');
            Text.fontSize(24);
            Text.fontWeight(700);
            Text.height(32);
            Text.textAlign(TextAlign.Start);
            Text.margin({
                top: 12,
                bottom: 12
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new TargetManage(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=TargetManagePage.js.map