import notify from '@ohos:notificationManager';
import promptAction from '@ohos:promptAction';
var DownloadState;
(function (DownloadState) {
    DownloadState["NOT_BEGIN"] = "\u672A\u5F00\u59CB";
    DownloadState["DOWNLOADING"] = "\u4E0B\u8F7D\u4E2D";
    DownloadState["PAUSE"] = "\u5DF2\u6682\u505C";
    DownloadState["FINISHED"] = "\u5DF2\u5B8C\u6210";
})(DownloadState || (DownloadState = {}));
export default class DownloadCard extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__progressValue = new ObservedPropertySimplePU(0
        // 任务状态
        , this, "progressValue");
        this.__state = new ObservedPropertySimplePU(DownloadState.NOT_BEGIN
        // 下载的文件名
        , this, "state");
        this.filename = '圣诞星.mp4';
        this.taskId = -1;
        this.notificationId = 999;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.progressValue !== undefined) {
            this.progressValue = params.progressValue;
        }
        if (params.state !== undefined) {
            this.state = params.state;
        }
        if (params.filename !== undefined) {
            this.filename = params.filename;
        }
        if (params.taskId !== undefined) {
            this.taskId = params.taskId;
        }
        if (params.notificationId !== undefined) {
            this.notificationId = params.notificationId;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__progressValue.purgeDependencyOnElmtId(rmElmtId);
        this.__state.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__progressValue.aboutToBeDeleted();
        this.__state.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get progressValue() {
        return this.__progressValue.get();
    }
    set progressValue(newValue) {
        this.__progressValue.set(newValue);
    }
    get state() {
        return this.__state.get();
    }
    set state(newValue) {
        this.__state.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create({ space: 10 });
            Row.debugLine("views/notification/DownloadCard.ets(29:5)");
            Row.width('100%');
            Row.borderRadius(20);
            Row.padding(15);
            Row.backgroundColor(Color.White);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777219, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("views/notification/DownloadCard.ets(30:7)");
            Image.width(50);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 5 });
            Column.debugLine("views/notification/DownloadCard.ets(31:7)");
            Column.layoutWeight(1);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("views/notification/DownloadCard.ets(32:9)");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.filename);
            Text.debugLine("views/notification/DownloadCard.ets(33:11)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`${this.progressValue}%`);
            Text.debugLine("views/notification/DownloadCard.ets(34:11)");
            Text.fontColor('#c1c2c1');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Progress.create({
                value: this.progressValue,
                total: 100,
            });
            Progress.debugLine("views/notification/DownloadCard.ets(39:9)");
            if (!isInitialRender) {
                Progress.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create({ space: 5 });
            Row.debugLine("views/notification/DownloadCard.ets(44:9)");
            Row.width('100%');
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`${(this.progressValue * 0.43).toFixed(2)}MB`);
            Text.debugLine("views/notification/DownloadCard.ets(45:11)");
            Text.fontSize(14);
            Text.fontColor('#c1c2c1');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Blank.create();
            Blank.debugLine("views/notification/DownloadCard.ets(47:11)");
            if (!isInitialRender) {
                Blank.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Blank.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (this.state === DownloadState.NOT_BEGIN) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Button.createWithLabel('开始');
                        Button.debugLine("views/notification/DownloadCard.ets(49:13)");
                        __Button__downloadButton();
                        Button.onClick(() => this.download());
                        if (!isInitialRender) {
                            Button.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Button.pop();
                });
            }
            else if (this.state === DownloadState.DOWNLOADING) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Button.createWithLabel('取消');
                        Button.debugLine("views/notification/DownloadCard.ets(53:13)");
                        __Button__downloadButton();
                        Button.backgroundColor('#d1d2d3');
                        Button.onClick(() => this.cancel());
                        if (!isInitialRender) {
                            Button.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Button.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Button.createWithLabel('暂停');
                        Button.debugLine("views/notification/DownloadCard.ets(56:13)");
                        __Button__downloadButton();
                        Button.onClick(() => this.pause());
                        if (!isInitialRender) {
                            Button.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Button.pop();
                });
            }
            else if (this.state === DownloadState.PAUSE) {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Button.createWithLabel('取消');
                        Button.debugLine("views/notification/DownloadCard.ets(60:13)");
                        __Button__downloadButton();
                        Button.backgroundColor('#d1d2d3');
                        Button.onClick(() => this.cancel());
                        if (!isInitialRender) {
                            Button.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Button.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Button.createWithLabel('继续');
                        Button.debugLine("views/notification/DownloadCard.ets(63:13)");
                        __Button__downloadButton();
                        Button.onClick(() => this.download());
                        if (!isInitialRender) {
                            Button.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Button.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(3, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Button.createWithLabel('打开');
                        Button.debugLine("views/notification/DownloadCard.ets(66:13)");
                        __Button__downloadButton();
                        Button.onClick(() => this.open());
                        if (!isInitialRender) {
                            Button.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Button.pop();
                });
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        Row.pop();
        Column.pop();
        Row.pop();
    }
    cancel() {
        // 取消定时任务
        if (this.taskId > 0) {
            clearInterval(this.taskId);
            this.taskId = -1;
        }
        // 清理下载任务进度
        this.progressValue = 0;
        // 标记任务状态：未开始
        this.state = DownloadState.NOT_BEGIN;
        // 发送通知
        this.publishDownloadNotification();
    }
    download() {
        // 清理旧任务
        if (this.taskId > 0) {
            clearInterval(this.taskId);
        }
        // 开启定时任务，模拟下载
        this.taskId = setInterval(() => {
            // 判断任务进度是否达到100
            if (this.progressValue >= 100) {
                // 任务完成了，应该取消定时任务
                clearInterval(this.taskId);
                this.taskId = -1;
                // 并且标记任务状态为已完成
                this.state = DownloadState.FINISHED;
                // 发送通知
                this.publishDownloadNotification();
                return;
            }
            // 模拟任务进度变更
            this.progressValue += 2;
        }, 500);
        // 标记任务状态：下载中
        this.state = DownloadState.DOWNLOADING;
        // 发送通知
        this.publishDownloadNotification();
    }
    pause() {
        // 取消定时任务
        if (this.taskId > 0) {
            clearInterval(this.taskId);
            this.taskId = -1;
        }
        // 标记任务状态：已暂停
        this.state = DownloadState.PAUSE;
        // 发送通知
        this.publishDownloadNotification();
    }
    open() {
        promptAction.showToast({
            message: '功能未实现'
        });
    }
    async publishDownloadNotification() {
        // 1.判断当前系统是否支持进度条模板
        let isSupport = await notify.isSupportTemplate('downloadTemplate');
        if (!isSupport) {
            // 当前系统不支持进度条模板
            return;
        }
        // 2.准备进度条模板的参数
        let template = {
            name: 'downloadTemplate',
            data: {
                progressValue: this.progressValue,
                progressMaxValue: 100
            }
        };
        let request = {
            id: this.notificationId,
            template: template,
            content: {
                contentType: notify.ContentType.NOTIFICATION_CONTENT_BASIC_TEXT,
                normal: {
                    title: this.filename + ':  ' + this.state,
                    text: '',
                    additionalText: this.progressValue + '%'
                }
            }
        };
        // 3.发送通知
        notify.publish(request)
            .then(() => console.log('test', '通知发送成功'))
            .catch(reason => console.log('test', '通知发送失败！', JSON.stringify(reason)));
    }
    rerender() {
        this.updateDirtyElements();
    }
}
function __Button__downloadButton() {
    Button.width(75);
    Button.height(28);
    Button.fontSize(14);
}
//# sourceMappingURL=DownloadCard.js.map