export default class CommonConstants {
}
/**
 * 标题字体大小
 */
CommonConstants.TITLE_FONT_SIZE = 30;
/**
 * 进度条大小
 */
CommonConstants.PROGRESS_WIDTH = 100;
/**
 * 任务数字字体大小
 */
CommonConstants.TASK_NUMBER_FONT_SIZE = 24;
/**
 * 新增按钮宽度
 */
CommonConstants.ADD_BUTTON_WIDTH = 200;
/**
 * 元素纵向间距
 */
CommonConstants.VERTICAL_SPACE = 10;
/**
 * 全屏宽度
 */
CommonConstants.FULL_WIDTH = '100%';
/**
 * 全屏高度
 */
CommonConstants.FULL_HEIGHT = '100%';
/**
 * 卡片宽度
 */
CommonConstants.CARD_WIDTH = '95%';
/**
 * 卡片圆角半径
 */
CommonConstants.CARD_BORDER_RADIUS = 15;
//# sourceMappingURL=CommmonConstants.js.map