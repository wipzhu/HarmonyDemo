import notify from '@ohos:notificationManager';
import image from '@ohos:multimedia.image';
import DownloadCard from '@bundle:com.example.myapplication/entry/ets/views/notification/DownloadCard';
import { Header } from '@bundle:com.example.myapplication/entry/ets/common/components/CommonComponents';
class NotificationPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.idx = 100;
        this.pixel = undefined;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.idx !== undefined) {
            this.idx = params.idx;
        }
        if (params.pixel !== undefined) {
            this.pixel = params.pixel;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    async aboutToAppear() {
        // 获取资源管理器
        let rm = getContext(this).resourceManager;
        // 读取图片
        let file = await rm.getMediaContent({ "id": 16777229, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
        // 创建PixelMap
        image.createImageSource(file.buffer).createPixelMap()
            .then(value => this.pixel = value)
            .catch(reason => console.log('testTag', '加载图片异常', JSON.stringify(reason)));
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 20 });
            Column.debugLine("pages/NotificationPage.ets(26:5)");
            Column.width('100%');
            Column.height('100%');
            Column.padding(5);
            Column.backgroundColor('#f1f2f3');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new Header(this, { title: '通知功能' }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel(`发送normalText通知`);
            Button.debugLine("pages/NotificationPage.ets(29:7)");
            Button.onClick(() => this.publishNormalTextNotification());
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel(`发送longText通知`);
            Button.debugLine("pages/NotificationPage.ets(31:7)");
            Button.onClick(() => this.publishLongTextNotification());
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel(`发送multiLine通知`);
            Button.debugLine("pages/NotificationPage.ets(33:7)");
            Button.onClick(() => this.publishMultiLineNotification());
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel(`发送Picture通知`);
            Button.debugLine("pages/NotificationPage.ets(35:7)");
            Button.onClick(() => this.publishPictureNotification());
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new 
                    // 下载功能卡片
                    DownloadCard(this, {}, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        Column.pop();
    }
    publishNormalTextNotification() {
        let request = {
            id: this.idx++,
            content: {
                contentType: notify.ContentType.NOTIFICATION_CONTENT_BASIC_TEXT,
                normal: {
                    title: '通知标题' + this.idx,
                    text: '通知内容详情',
                    additionalText: '通知附加内容'
                }
            },
            showDeliveryTime: true,
            deliveryTime: new Date().getTime(),
            groupName: 'wechat',
            slotType: notify.SlotType.SOCIAL_COMMUNICATION
        };
        this.publish(request);
    }
    publishLongTextNotification() {
        let request = {
            id: this.idx++,
            content: {
                contentType: notify.ContentType.NOTIFICATION_CONTENT_LONG_TEXT,
                longText: {
                    title: '通知标题' + this.idx,
                    text: '通知内容详情',
                    additionalText: '通知附加内容',
                    longText: '通知中的长文本，我很长，我很长，我很长，我很长，我很长，我很长，我很长',
                    briefText: '通知概要和总结',
                    expandedTitle: '通知展开时的标题' + this.idx
                }
            }
        };
        this.publish(request);
    }
    publishMultiLineNotification() {
        let request = {
            id: this.idx++,
            content: {
                contentType: notify.ContentType.NOTIFICATION_CONTENT_MULTILINE,
                multiLine: {
                    title: '通知标题' + this.idx,
                    text: '通知内容详情',
                    additionalText: '通知附加内容',
                    briefText: '通知概要和总结',
                    longTitle: '展开时的标题，我很宽，我很宽，我很宽',
                    lines: [
                        '第一行',
                        '第二行',
                        '第三行',
                        '第四行',
                    ]
                }
            }
        };
        this.publish(request);
    }
    publishPictureNotification() {
        let request = {
            id: this.idx++,
            content: {
                contentType: notify.ContentType.NOTIFICATION_CONTENT_PICTURE,
                picture: {
                    title: '通知标题' + this.idx,
                    text: '通知内容详情',
                    additionalText: '通知附加内容',
                    briefText: '通知概要和总结',
                    expandedTitle: '展开后标题' + this.idx,
                    picture: this.pixel
                }
            }
        };
        this.publish(request);
    }
    publish(request) {
        notify.publish(request)
            .then(() => console.log('notify test', '发送通知成功'))
            .then(reason => console.log('notify test', '发送通知失败', JSON.stringify(reason)));
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new NotificationPage(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=NotificationPage.js.map