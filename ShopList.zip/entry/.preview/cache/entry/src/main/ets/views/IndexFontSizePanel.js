import PreferencesUtil from '@bundle:com.example.myapplication/entry/ets/common/util/PreferencesUtil';
export default class IndexFontSizePanel extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__fontSize = this.initializeConsume("fontSize", "fontSize");
        this.fontSizLabel = {
            14: '小',
            16: '标准',
            18: '大',
            20: '特大',
        };
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.fontSizLabel !== undefined) {
            this.fontSizLabel = params.fontSizLabel;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        this.__fontSize.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get fontSize() {
        return this.__fontSize.get();
    }
    set fontSize(newValue) {
        this.__fontSize.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("views/IndexFontSizePanel.ets(14:5)");
            Column.width('100%');
            Column.padding(15);
            Column.backgroundColor('#fff1f0f0');
            Column.borderRadius(20);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.fontSizLabel[this.fontSize]);
            Text.debugLine("views/IndexFontSizePanel.ets(15:7)");
            Text.fontSize(20);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create({ space: 5 });
            Row.debugLine("views/IndexFontSizePanel.ets(16:7)");
            Row.width('100%');
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('A');
            Text.debugLine("views/IndexFontSizePanel.ets(17:9)");
            Text.fontSize(14);
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Slider.create({
                min: 14,
                max: 20,
                step: 2,
                value: this.fontSize
            });
            Slider.debugLine("views/IndexFontSizePanel.ets(18:9)");
            Slider.showSteps(true);
            Slider.trackThickness(6);
            Slider.layoutWeight(1);
            Slider.onChange(val => {
                // 修改字体大小
                this.fontSize = val;
                // 写入Preferences
                PreferencesUtil.putPreferenceValue('MyPreferences', 'IndexFontSize', val);
            });
            if (!isInitialRender) {
                Slider.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('A');
            Text.debugLine("views/IndexFontSizePanel.ets(33:9)");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=IndexFontSizePanel.js.map