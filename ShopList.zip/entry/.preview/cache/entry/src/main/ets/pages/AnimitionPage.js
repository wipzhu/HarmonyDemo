import curves from '@native:ohos.curves';
class SpringMotionTest extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.sx = 120;
        this.sy = 120;
        this.maxRadius = 100;
        this.diameter = 50;
        this.__positionX = new ObservedPropertySimplePU(this.sx, this, "positionX");
        this.__positionY = new ObservedPropertySimplePU(this.sy, this, "positionY");
        this.__mX = new ObservedPropertySimplePU(100, this, "mX");
        this.__mY = new ObservedPropertySimplePU(100, this, "mY");
        this.__angle = new ObservedPropertySimplePU(0, this, "angle");
        this.__isBegin = new ObservedPropertySimplePU(false, this, "isBegin");
        this.__src = new ObservedPropertyObjectPU({ "id": 16777231, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" }, this, "src");
        this.taskId = -1;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.sx !== undefined) {
            this.sx = params.sx;
        }
        if (params.sy !== undefined) {
            this.sy = params.sy;
        }
        if (params.maxRadius !== undefined) {
            this.maxRadius = params.maxRadius;
        }
        if (params.diameter !== undefined) {
            this.diameter = params.diameter;
        }
        if (params.positionX !== undefined) {
            this.positionX = params.positionX;
        }
        if (params.positionY !== undefined) {
            this.positionY = params.positionY;
        }
        if (params.mX !== undefined) {
            this.mX = params.mX;
        }
        if (params.mY !== undefined) {
            this.mY = params.mY;
        }
        if (params.angle !== undefined) {
            this.angle = params.angle;
        }
        if (params.isBegin !== undefined) {
            this.isBegin = params.isBegin;
        }
        if (params.src !== undefined) {
            this.src = params.src;
        }
        if (params.taskId !== undefined) {
            this.taskId = params.taskId;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__positionX.purgeDependencyOnElmtId(rmElmtId);
        this.__positionY.purgeDependencyOnElmtId(rmElmtId);
        this.__mX.purgeDependencyOnElmtId(rmElmtId);
        this.__mY.purgeDependencyOnElmtId(rmElmtId);
        this.__angle.purgeDependencyOnElmtId(rmElmtId);
        this.__isBegin.purgeDependencyOnElmtId(rmElmtId);
        this.__src.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__positionX.aboutToBeDeleted();
        this.__positionY.aboutToBeDeleted();
        this.__mX.aboutToBeDeleted();
        this.__mY.aboutToBeDeleted();
        this.__angle.aboutToBeDeleted();
        this.__isBegin.aboutToBeDeleted();
        this.__src.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get positionX() {
        return this.__positionX.get();
    }
    set positionX(newValue) {
        this.__positionX.set(newValue);
    }
    get positionY() {
        return this.__positionY.get();
    }
    set positionY(newValue) {
        this.__positionY.set(newValue);
    }
    get mX() {
        return this.__mX.get();
    }
    set mX(newValue) {
        this.__mX.set(newValue);
    }
    get mY() {
        return this.__mY.get();
    }
    set mY(newValue) {
        this.__mY.set(newValue);
    }
    get angle() {
        return this.__angle.get();
    }
    set angle(newValue) {
        this.__angle.set(newValue);
    }
    get isBegin() {
        return this.__isBegin.get();
    }
    set isBegin(newValue) {
        this.__isBegin.set(newValue);
    }
    get src() {
        return this.__src.get();
    }
    set src(newValue) {
        this.__src.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/AnimitionPage.ets(22:5)");
            Row.height('100%');
            Row.width('100%');
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create();
            Stack.debugLine("pages/AnimitionPage.ets(23:7)");
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777234, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("pages/AnimitionPage.ets(24:9)");
            Image.width('100%');
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (!this.isBegin) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Row.create();
                        Row.debugLine("pages/AnimitionPage.ets(27:11)");
                        if (!isInitialRender) {
                            Row.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Button.createWithLabel('开始游戏');
                        Button.debugLine("pages/AnimitionPage.ets(28:13)");
                        Button.onClick(() => {
                            // 点击后显示小鱼和摇杆
                            Context.animateTo({ duration: 1000 }, () => {
                                this.isBegin = true;
                            });
                        });
                        if (!isInitialRender) {
                            Button.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Button.pop();
                    Row.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Image.create(this.src);
                        Image.debugLine("pages/AnimitionPage.ets(37:11)");
                        Image.position({ x: this.mX - 20, y: this.mY - 20 });
                        Image.rotate({ z: 1, angle: this.angle, centerX: '50%', centerY: '50%' });
                        Image.transition({ opacity: 0, scale: { x: 0, y: 0 } });
                        Image.width(40);
                        Image.height(40);
                        if (!isInitialRender) {
                            Image.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Row.create();
                        Row.debugLine("pages/AnimitionPage.ets(44:11)");
                        Row.height(240);
                        Row.width(240);
                        Row.justifyContent(FlexAlign.Center);
                        Row.position({ x: 0, y: 120 });
                        Row.onTouch(this.handleTouchEvent.bind(this));
                        if (!isInitialRender) {
                            Row.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Circle.create({ width: 200, height: 200 });
                        Circle.debugLine("pages/AnimitionPage.ets(45:13)");
                        Circle.fill('#20101010');
                        Circle.position({ x: this.sx - this.maxRadius, y: this.sy - this.maxRadius });
                        if (!isInitialRender) {
                            Circle.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Circle.create({ width: this.diameter, height: this.diameter });
                        Circle.debugLine("pages/AnimitionPage.ets(48:13)");
                        Circle.fill('#403A3A3A');
                        Circle.position({ x: this.positionX - this.diameter / 2, y: this.positionY - this.diameter / 2 });
                        if (!isInitialRender) {
                            Circle.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Row.pop();
                });
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        Stack.pop();
        Row.pop();
    }
    getDistance(x, y) {
        let d = Math.sqrt(x * x + y * y);
        return Math.min(d, this.maxRadius);
    }
    handleTouchEvent(event) {
        if (event.type === TouchType.Move) {
            // 减去半径，以使球的中心运动到手指位置
            let x = event.touches[0].x;
            let y = event.touches[0].y;
            // 计算手指当前坐标与起点坐标差异
            let vx = x - this.sx;
            let vy = y - this.sy;
            // 计算当前坐标到起点的距离
            let distance = this.getDistance(vx, vy);
            // 计算夹角
            let angle = Math.atan2(vy, vx);
            let cos = Math.cos(angle);
            let sin = Math.sin(angle);
            Context.animateTo({ curve: curves.responsiveSpringMotion() }, () => {
                // 改变摇杆位置
                this.positionX = cos * distance + this.sx;
                this.positionY = sin * distance + this.sy;
                // 改变小鱼方向
                if (Math.abs(angle * 2) < Math.PI) {
                    this.src = { "id": 16777231, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" };
                }
                else {
                    this.src = { "id": 16777228, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" };
                    angle += Math.PI;
                }
            });
            if (this.taskId !== -1) {
                // 清空旧任务
                clearInterval(this.taskId);
            }
            this.taskId = setInterval(() => {
                // 改变小鱼位置
                this.angle = (angle * 180) / Math.PI;
                let mx = 5 * cos;
                let my = 5 * sin;
                this.mX += mx;
                this.mY += my;
            }, 40);
        }
        else if (event.type === TouchType.Up) {
            // 离手时，使用springMotion曲线
            Context.animateTo({ curve: curves.springMotion() }, () => {
                this.positionX = this.sx;
                this.positionY = this.sy;
                this.angle = 0;
                console.info(`touchUp, animateTo x:100, y:100`);
            });
            clearInterval(this.taskId);
            this.taskId = -1;
        }
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new SpringMotionTest(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=AnimitionPage.js.map