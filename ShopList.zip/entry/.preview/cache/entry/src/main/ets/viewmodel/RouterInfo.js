export default class RouterInfo {
    constructor(url, title) {
        this.url = url;
        this.title = title;
    }
}
//# sourceMappingURL=RouterInfo.js.map