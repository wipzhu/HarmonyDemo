export default class TaskStatistics extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.latestUpdateDate = undefined;
        this.totalTaskNumber = undefined;
        this.completeTaskNumber = undefined;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.latestUpdateDate !== undefined) {
            this.latestUpdateDate = params.latestUpdateDate;
        }
        if (params.totalTaskNumber !== undefined) {
            this.totalTaskNumber = params.totalTaskNumber;
        }
        if (params.completeTaskNumber !== undefined) {
            this.completeTaskNumber = params.completeTaskNumber;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("views/TaskStatistics.ets(9:5)");
            Column.padding(16);
            Column.width('93.3%');
            Column.height(187);
            Column.backgroundColor('#FFF');
            Column.borderRadius(25);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.TargetItem.bind(this)();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("views/TaskStatistics.ets(12:7)");
            Row.layoutWeight(1);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        Column.pop();
    }
    TargetItem(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create({ space: 10 });
            Row.debugLine("views/TaskStatistics.ets(26:5)");
            Row.width('100%');
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777224, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("views/TaskStatistics.ets(27:7)");
            Image.width(96);
            Image.height(96);
            Image.objectFit(ImageFit.Fill);
            Image.borderRadius(12);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 15 });
            Column.debugLine("views/TaskStatistics.ets(32:7)");
            Column.height('100%');
            Column.justifyContent(FlexAlign.Center);
            Column.alignItems(HorizontalAlign.Start);
            Column.layoutWeight(5);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('第一季度营运目标');
            Text.debugLine("views/TaskStatistics.ets(33:9)");
            Text.fontSize(18);
            Text.fontWeight(700);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('实现用户量与用户活跃度提升');
            Text.debugLine("views/TaskStatistics.ets(36:9)");
            __Text__opacityTextStyle();
            Text.fontSize(15);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
/**
 * Custom Transparent Text Styles
 */
function __Text__opacityTextStyle() {
    Text.fontSize(12);
    Text.fontColor('#182431');
    Text.opacity(0.4);
    Text.fontWeight(500);
}
//# sourceMappingURL=TaskStatistics.js.map