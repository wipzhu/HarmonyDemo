export default class ShopInfo {
}
//# sourceMappingURL=ShopInfo.js.map