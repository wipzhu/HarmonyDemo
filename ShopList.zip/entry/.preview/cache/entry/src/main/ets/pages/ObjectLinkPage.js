"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var Task_1;
let Total = class Total {
    constructor() {
        this.value = 0;
    }
};
Total = __decorate([
    Observed
], Total);
let Finish = class Finish {
    constructor() {
        this.value = 0;
    }
};
Finish = __decorate([
    Observed
], Finish);
let Statistics = class Statistics {
    constructor() {
        this.totalTask = new Total();
        this.finishTask = new Finish();
    }
};
Statistics = __decorate([
    Observed
], Statistics);
let Task = Task_1 = class Task {
    constructor() {
        this.name = `任务${Task_1.id++}`;
        this.finished = false;
    }
};
Task.id = 1;
Task = Task_1 = __decorate([
    Observed
], Task);
class PropPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__stat = new ObservedPropertyObjectPU(new Statistics(), this, "stat");
        this.addProvidedVar("stat", this.__stat);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.stat !== undefined) {
            this.stat = params.stat;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        this.__stat.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get stat() {
        return this.__stat.get();
    }
    set stat(newValue) {
        this.__stat.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 10 });
            Column.debugLine("pages/ObjectLinkPage.ets(34:5)");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#F1F2F3');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new 
                    // 任务统计
                    TaskStatistics(this, { totalTask: this.stat.totalTask, finishTask: this.stat.finishTask }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        totalTask: this.stat.totalTask, finishTask: this.stat.finishTask
                    });
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new 
                    // 任务列表
                    TaskList(this, {}, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class TaskStatistics extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__totalTask = new SynchedPropertyNesedObjectPU(params.totalTask, this, "totalTask");
        this.__finishTask = new SynchedPropertyNesedObjectPU(params.finishTask, this, "finishTask");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        this.__totalTask.set(params.totalTask);
        this.__finishTask.set(params.finishTask);
    }
    updateStateVars(params) {
        this.__totalTask.set(params.totalTask);
        this.__finishTask.set(params.finishTask);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__totalTask.purgeDependencyOnElmtId(rmElmtId);
        this.__finishTask.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__totalTask.aboutToBeDeleted();
        this.__finishTask.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get totalTask() {
        return this.__totalTask.get();
    }
    get finishTask() {
        return this.__finishTask.get();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/ObjectLinkPage.ets(64:5)");
            Row.width('95%');
            Row.padding(20);
            Row.backgroundColor(Color.White);
            Row.borderRadius(15);
            Row.shadow({ radius: 6, color: '#1F000000', offsetX: 2, offsetY: 4 });
            Row.margin({ top: 20, bottom: 10 });
            Row.justifyContent(FlexAlign.SpaceEvenly);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('任务进度 ：');
            Text.debugLine("pages/ObjectLinkPage.ets(65:7)");
            Text.fontWeight(700);
            Text.fontSize(24);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create();
            Stack.debugLine("pages/ObjectLinkPage.ets(68:7)");
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Progress.create({
                value: this.finishTask.value,
                total: this.totalTask.value,
                type: ProgressType.Ring
            });
            Progress.debugLine("pages/ObjectLinkPage.ets(69:9)");
            Progress.value(this.finishTask.value);
            Progress.width(80);
            if (!isInitialRender) {
                Progress.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/ObjectLinkPage.ets(76:9)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`${this.finishTask.value} `);
            Text.debugLine("pages/ObjectLinkPage.ets(77:11)");
            Text.fontSize(24);
            Text.fontColor('#36D');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`/ ${this.totalTask.value}`);
            Text.debugLine("pages/ObjectLinkPage.ets(80:11)");
            Text.fontSize(24);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Stack.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class TaskList extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__tasks = new ObservedPropertyObjectPU([], this, "tasks");
        this.__stat = this.initializeConsume("stat", "stat");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.tasks !== undefined) {
            this.tasks = params.tasks;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__tasks.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__tasks.aboutToBeDeleted();
        this.__stat.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get tasks() {
        return this.__tasks.get();
    }
    set tasks(newValue) {
        this.__tasks.set(newValue);
    }
    get stat() {
        return this.__stat.get();
    }
    set stat(newValue) {
        this.__stat.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 10 });
            Column.debugLine("pages/ObjectLinkPage.ets(104:5)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 新增按钮
            Button.createWithLabel('新增任务');
            Button.debugLine("pages/ObjectLinkPage.ets(106:7)");
            // 新增按钮
            Button.onClick(() => {
                this.tasks.push(new Task());
                this.stat.totalTask.value = this.tasks.length;
            });
            // 新增按钮
            Button.width('95%');
            // 新增按钮
            Button.margin({ bottom: 10 });
            // 新增按钮
            Button.shadow({ radius: 6, color: '#3F000000', offsetX: 2, offsetY: 4 });
            if (!isInitialRender) {
                // 新增按钮
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 新增按钮
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = (_item, index) => {
                const item = _item;
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Row.create();
                    Row.debugLine("pages/ObjectLinkPage.ets(117:11)");
                    Row.width('95%');
                    Row.padding(20);
                    Row.backgroundColor(Color.White);
                    Row.borderRadius(15);
                    Row.shadow({ radius: 6, color: '#1F000000', offsetX: 2, offsetY: 4 });
                    Row.justifyContent(FlexAlign.SpaceBetween);
                    if (!isInitialRender) {
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    If.create();
                    if (item.finished) {
                        this.ifElseBranchUpdateFunction(0, () => {
                            this.observeComponentCreation((elmtId, isInitialRender) => {
                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                Text.create(item.name);
                                Text.debugLine("pages/ObjectLinkPage.ets(119:15)");
                                Text.decoration({ type: TextDecorationType.LineThrough });
                                Text.fontColor('#ddd');
                                if (!isInitialRender) {
                                    Text.pop();
                                }
                                ViewStackProcessor.StopGetAccessRecording();
                            });
                            Text.pop();
                        });
                    }
                    else {
                        this.ifElseBranchUpdateFunction(1, () => {
                            this.observeComponentCreation((elmtId, isInitialRender) => {
                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                Text.create(item.name);
                                Text.debugLine("pages/ObjectLinkPage.ets(123:15)");
                                if (!isInitialRender) {
                                    Text.pop();
                                }
                                ViewStackProcessor.StopGetAccessRecording();
                            });
                            Text.pop();
                        });
                    }
                    if (!isInitialRender) {
                        If.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                If.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Checkbox.create({ name: item.name });
                    Checkbox.debugLine("pages/ObjectLinkPage.ets(125:13)");
                    Checkbox.select(item.finished);
                    Checkbox.onChange(val => {
                        item.finished = val;
                        this.stat.finishTask.value = this.tasks.filter(item => item.finished).length;
                    });
                    if (!isInitialRender) {
                        Checkbox.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Checkbox.pop();
                Row.pop();
            };
            this.forEachUpdateFunction(elmtId, this.tasks, forEachItemGenFunction, undefined, true, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new PropPage(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=ObjectLinkPage.js.map