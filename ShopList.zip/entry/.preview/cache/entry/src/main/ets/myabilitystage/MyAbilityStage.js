import AbilityStage from '@ohos:app.ability.AbilityStage';
export default class MyAbilityStage extends AbilityStage {
    onAcceptWant(want) {
        if (want.abilityName === 'DocumentAbility') {
            return `DocAbilityInstance_${want.parameters.instanceKey}`;
        }
        return '';
    }
}
//# sourceMappingURL=MyAbilityStage.js.map